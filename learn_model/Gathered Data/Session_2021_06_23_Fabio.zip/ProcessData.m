clear; clc;

nSOM   = 10;
nRange = 30;
nRep   = 1;

% Calibration
calib_campose = readtable('Converted CSV/n10_calibration_campose.csv');
calib_PoseRC = table2array(calib_campose(end,2:end));
calib_pRC = calib_PoseRC(1:3);
calib_qRC = [calib_PoseRC(7) calib_PoseRC(4:6)]; %wxyz
calib_RRC = quat2rotm(calib_qRC);
TRC = [calib_RRC calib_pRC'; 0 0 0 1];

% Load real trajectory data
mesh_table = readtable(['Converted CSV/n', num2str(nSOM), ...
                        '_range', num2str(nRange), ...
                        '_rep', num2str(nRep),'_mesh.csv']);
TableOffset = 5;
Npt = size(mesh_table,1);

% Transform to Robot Base
All_SOMpos = zeros(3*nSOM^2, Npt);
All_SOMt = zeros(1, Npt);
t0 = table2array(mesh_table(1,3))/1e9;
for ptk=1:Npt
    tCAM = table2array(mesh_table(ptk, 3))/1e9 - t0;
    xCAM = table2array(mesh_table(ptk, TableOffset+1:TableOffset+nSOM^2))';
    yCAM = table2array(mesh_table(ptk, TableOffset+nSOM^2+1:TableOffset+2*nSOM^2))';
    zCAM = table2array(mesh_table(ptk, TableOffset+2*nSOM^2+1:TableOffset+3*nSOM^2))';

    dxC = max(xCAM)-min(xCAM);
    dyC = max(yCAM)-min(yCAM);

    xCsq = reshape(xCAM, nSOM,nSOM);
    yCsq = reshape(yCAM, nSOM,nSOM);
    zCsq = reshape(zCAM, nSOM,nSOM);

    % Desired: x increasing, then y decreasing
    if range(xCsq(:,1)) < 0.3*dxC
        % First 10 on same x --> Transpose!
        xCsq = xCsq';
        yCsq = yCsq';
        zCsq = zCsq';
    end
    if (xCsq(end,1) - xCsq(1,1)) < 0
        % Decreasing x --> Invert!
        xCsq = xCsq(end:-1:1,:);
        yCsq = yCsq(end:-1:1,:);
        zCsq = zCsq(end:-1:1,:);
    end
    if (yCsq(1,end) - yCsq(1,1)) > 0
        % Increasing y --> Invert!
        xCsq = xCsq(:,end:-1:1);
        yCsq = yCsq(:,end:-1:1);
        zCsq = zCsq(:,end:-1:1);
    end

    xCAMord = reshape(xCsq, nSOM^2,1);
    yCAMord = reshape(yCsq, nSOM^2,1);
    zCAMord = reshape(zCsq, nSOM^2,1);

    % Apply Transform to all points
    xSOM = zeros(size(xCAMord));
    ySOM = zeros(size(yCAMord));
    zSOM = zeros(size(zCAMord));
    for pj=1:length(xCAMord)

        % Filter NaNs in depth (z)
        if isnan(zCAMord(pj))
            zSum = 0; zN = 0; pj1 = pj-1; 
            if (floor(pj1/nSOM)>0) && ~isnan(zCAMord(pj-10))
            	zSum=zSum+zCAMord(pj-10); zN=zN+1;
            end
            if(floor(pj1/nSOM)<nSOM-1) && ~isnan(zCAMord(pj+10))
                zSum=zSum+zCAMord(pj+10); zN=zN+1;
            end
            if(mod(pj1,nSOM)>0) && ~isnan(zCAMord(pj-1))
                zSum=zSum+zCAMord(pj-1); zN=zN+1;
            end
            if(mod(pj1,nSOM)<nSOM-1) && ~isnan(zCAMord(pj+1))
                zSum=zSum+zCAMord(pj+1); zN=zN+1;
            end

            zCAMord(pj) = zSum/zN;
        end

        Pt = [xCAMord(pj) yCAMord(pj) zCAMord(pj) 1]';

        RPt = TRC*Pt;

        xSOM(pj) = RPt(1);
        ySOM(pj) = RPt(2);
        zSOM(pj) = RPt(3);
    end
    SOMpos = [xSOM;ySOM;zSOM];
    
    % Store data
    All_SOMpos(:,ptk) = SOMpos;
    All_SOMt(:,ptk) = tCAM;
    
end

% Plot final mesh
lt = [-0.5 0.6 -1 0.1 -0.3 0.6];
pov = [-5 10]; %[-25 20]; %[-70 20];

scatter3(xSOM(1:nSOM), ySOM(1:nSOM), zSOM(1:nSOM), '.r');
hold on
scatter3(xSOM(1), ySOM(1), zSOM(1), '*r');
scatter3(xSOM(nSOM+1:end), ySOM(nSOM+1:end), zSOM(nSOM+1:end), '.b');
hold off
legend off
axis equal;
axis(lt);
fig1.Children.View = pov;

box on;
xlabel('X');
ylabel('Y');
zlabel('Z');


