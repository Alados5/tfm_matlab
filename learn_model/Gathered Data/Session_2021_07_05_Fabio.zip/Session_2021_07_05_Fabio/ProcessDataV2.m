clear; clc;

nRange = 30;
nRep   = 1;

% Load real trajectory data
data_table = readtable(['range', num2str(nRange), ...
                        '_rep', num2str(nRep),'_somstate.csv']);
TableOffset = 5;
Npt = size(data_table,1);

nSOM = data_table.field_size(1);
t0 = table2array(data_table(1,3))/1e9;
data = table2array(data_table(:, [3,6:5+3*nSOM^2]));
data(:,1) = data(:,1)/1e9 - t0;

tcp_table = readtable(['range', num2str(nRange), ...
                       '_rep', num2str(nRep),'_tcp.csv']);
tcp_t0 = table2array(tcp_table(1,3))/1e9;
tcp_data = table2array(tcp_table(:, [3,5:end]));
tcp_data(:,1) = tcp_data(:,1)/1e9 - t0;

% Corner coordinates
coord_bot = [1 nSOM 1+nSOM^2 nSOM+nSOM^2 1+2*nSOM^2 nSOM+2*nSOM^2];
coord_top = [nSOM^2-nSOM+1 nSOM^2 2*nSOM^2-nSOM+1 2*nSOM^2 3*nSOM^2-nSOM+1 3*nSOM^2];

% Plot 3D trajectories of corners
figure(1);
plot3(data(:,1+coord_bot(1:2)), data(:,1+coord_bot(3:4)), data(:,1+coord_bot(5:6)));
grid on; box on; axis equal
hold on;
plot3(data(:,1+coord_top(1:2)), data(:,1+coord_top(3:4)), data(:,1+coord_top(5:6)));
hold off;
xlabel('X');
ylabel('Y');
zlabel('Z');


% Plot initial mesh
lt = [-0.4 0.4 -1 0.2 -0.2 0.6];
pov = [-5 10]; %[-25 20]; %[-70 20];

figure(2);
scatter3(data(1,2:1+nSOM), data(1,2+nSOM^2:1+nSOM^2+nSOM), data(1,2+2*nSOM^2:1+2*nSOM^2+nSOM), '.r');
hold on
scatter3(data(1,2), data(1,2+nSOM^2), data(1,2+2*nSOM^2), '*r');
scatter3(data(1,2+nSOM:1+nSOM^2), ...
         data(1,2+nSOM^2+nSOM:1+2*nSOM^2), ...
         data(1,2+2*nSOM^2+nSOM:1+3*nSOM^2), '.b');
hold off
legend off
axis equal;
axis(lt);
fig1.Children.View = pov;

box on;
xlabel('X');
ylabel('Y');
zlabel('Z');


% Plot evolution of top corners vs time
figure(3);
subplot(1,2,1)
plot(data(:,1), data(:,1+coord_top([1,3,5])))
subplot(1,2,2)
plot(data(:,1), data(:,1+coord_top([2,4,6])))


